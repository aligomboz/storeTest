@extends('layouts.admin')
@section('content')

    show

@endsection
