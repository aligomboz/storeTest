<div>
    <a href="#" class="nav-link dropdown-toggle withoutAfter" id="notificationDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <span class="badge badge-danger badge-counter"><?php echo e($unReadNotificationsCount); ?></span>
        <i class="fas fa-user-alt mr-2 text-gray"></i>
    </a>
    <div class="dropdown-menu mt-3 notification-dropdown" aria-labelledby="notificationDropdown">

        <?php $__empty_1 = true; $__currentLoopData = $unReadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            
                <a class="dropdown-item d-flex align-items-center" wire:click="markAsRead('<?php echo e($notification->id); ?>')">
                    <div class="mr-3">
                        <div class="icon-circle bg-primary">
                            <i class="fas fa-file-alt text-white"></i>
                        </div>
                    </div>
                    <div>
                        <div class="small text-gray-500"><?php echo e($notification->data['created_date']); ?></div>
                        <span class="font-weight-bold">Order #<?php echo e($notification->data['order_ref']); ?> completed successfully.</span>
                    </div>
                </a>
            

            <?php if($notification->type == 'App\Notifications\Frontend\Customer\OrderCreatedNotification'): ?>
                <a class="dropdown-item d-flex align-items-center" wire:click="markAsRead('<?php echo e($notification->id); ?>')">
                    <div class="mr-3">
                        <div class="icon-circle bg-primary">
                            <i class="fas fa-file-alt text-white"></i>
                        </div>
                    </div>
                    <div>
                        <div class="small text-gray-500"><?php echo e($notification->data['created_date']); ?></div>
                        <span class="font-weight-bold">Order <?php echo e($notification->data['order_ref']); ?> status is <?php echo e($notification->data['last_transaction']); ?></span>
                    </div>
                </a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="dropdown-item text-center">No notifications found!</div>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\store\resources\views/livewire/frontend/header/notification-component.blade.php ENDPATH**/ ?>