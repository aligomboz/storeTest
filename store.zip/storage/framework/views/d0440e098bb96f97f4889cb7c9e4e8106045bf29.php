<?php $__env->startSection('content'); ?>

    <section class="py-5">
        <div class="container">
            <div class="row mb-5">
                <div class="col-lg-6">
                    <!-- PRODUCT SLIDER-->
                    <div class="row m-sm-0" dir="ltr">
                        <div class="col-sm-2 p-sm-0 order-2 order-sm-1 mt-2 mt-sm-0">
                            <div class="owl-thumbs d-flex flex-row flex-sm-column" data-slider-id="1">
                                <?php $__currentLoopData = $product->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="owl-thumb-item flex-fill mb-2 <?php echo e(!$loop->last ? 'mr-2 mr-sm-0' : null); ?>">
                                    <img class="w-100" src="<?php echo e(asset('assets/products/'.$media->file_name)); ?>" alt="<?php echo e($product->name); ?>">
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="col-sm-10 order-1 order-sm-2">
                            <div class="owl-carousel product-slider" data-slider-id="1">
                                <?php $__currentLoopData = $product->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="d-block" href="<?php echo e(asset('assets/products/'.$media->file_name)); ?>" data-lightbox="product" title="<?php echo e($product->name); ?>">
                                    <img class="img-fluid" src="<?php echo e(asset('assets/products/'.$media->file_name)); ?>" alt="<?php echo e($product->name); ?>">
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- PRODUCT DETAILS-->
                <div class="col-lg-6">
                    <h1><?php echo e($product->name); ?></h1>
                    <p class="text-muted lead">$<?php echo e($product->price); ?></p>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.show-product-component', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('AN3x79a')) {
    $componentId = $_instance->getRenderedChildComponentId('AN3x79a');
    $componentTag = $_instance->getRenderedChildComponentTagName('AN3x79a');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AN3x79a');
} else {
    $response = \Livewire\Livewire::mount('frontend.show-product-component', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('AN3x79a', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>

            <!-- DETAILS TABS-->
            <ul class="nav nav-tabs border-0" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="description-tab" data-toggle="tab" href="#description" role="tab" aria-controls="description" aria-selected="true"><?php echo e(__('Product description')); ?></a>
                </li>

            </ul>

            <div class="tab-content mb-5" id="myTabContent">
                <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-tab">
                    <div class="p-1 p-lg-4 bg-white">
                        <p class="text-muted text-small mb-0">
                            <?php echo $product->description; ?>

                        </p>
                    </div>
                </div>

            </div>
            <!-- RELATED PRODUCTS-->

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.related-products-component', ['relatedProducts' => $relatedProducts])->html();
} elseif ($_instance->childHasBeenRendered('F5bxIi4')) {
    $componentId = $_instance->getRenderedChildComponentId('F5bxIi4');
    $componentTag = $_instance->getRenderedChildComponentTagName('F5bxIi4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('F5bxIi4');
} else {
    $response = \Livewire\Livewire::mount('frontend.related-products-component', ['relatedProducts' => $relatedProducts]);
    $html = $response->html();
    $_instance->logRenderedChild('F5bxIi4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/frontend/product.blade.php ENDPATH**/ ?>