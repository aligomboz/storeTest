<?php $__env->startSection('content'); ?>
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row px-4 px-lg-5 py-lg-4 align-items-center">
                <div class="col-lg-6">
                    <h1 class="h2 text-uppercase mb-0"><?php echo e(__('Wish List')); ?></h1>
                </div>
                <div class="col-lg-6 text-lg-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-lg-end mb-0 px-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.index')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Wish List')); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section>
    <section class="py-5">
    <h2 class="h5 text-uppercase mb-4"><?php echo e(__('Wish List')); ?></h2>
    <div class="row">
        <div class="col-lg-12 mb-4 mb-lg-0">
            <!-- CART TABLE-->
            <div class="table-responsive mb-4">
                <table class="table">
                    <thead class="bg-light">
                    <tr>
                        <th class="border-0" scope="col"><strong class="text-small text-uppercase"><?php echo e(__('Product')); ?></strong></th>
                        <th class="border-0" scope="col"><strong class="text-small text-uppercase"><?php echo e(__('Price')); ?></strong></th>
                        <th class="border-0" scope="col"><strong class="text-small text-uppercase"><?php echo e(__('Move to cart')); ?></strong></th>
                        <th class="border-0" scope="col"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = Cart::instance('wishlist')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.wish-list-item-component', ['item' => $item->rowId])->html();
} elseif ($_instance->childHasBeenRendered($item->rowId)) {
    $componentId = $_instance->getRenderedChildComponentId($item->rowId);
    $componentTag = $_instance->getRenderedChildComponentTagName($item->rowId);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($item->rowId);
} else {
    $response = \Livewire\Livewire::mount('frontend.wish-list-item-component', ['item' => $item->rowId]);
    $html = $response->html();
    $_instance->logRenderedChild($item->rowId, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="pl-0 border-light" colspan="5">
                                <p class="text-center">
                                    <?php echo e(__('No items are found on your wish list!')); ?>

                                </p>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/frontend/wishlist.blade.php ENDPATH**/ ?>