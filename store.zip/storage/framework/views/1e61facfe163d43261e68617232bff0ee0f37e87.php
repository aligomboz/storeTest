<div x-data="{ formShow: <?php if ((object) ('showForm') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('showForm'->value()); ?>')<?php echo e('showForm'->hasModifier('defer') ? '.defer' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('showForm'); ?>')<?php endif; ?> }">
    <div class="d-flex">
        <h2 class="h5 text-uppercase mb-4"><?php echo e(__('Addresses')); ?></h2>
        <div class="ml-auto">
            <button type="button" @click="formShow = true" class="btn btn-primary rounded shadow">
                <?php echo e(__('Add new address')); ?>

            </button>
        </div>
    </div>

    <form wire:submit.prevent="<?php echo e($editMode ? 'update_address' : 'store_address'); ?>" x-show="formShow" @click.away="formShow = false">
        <?php if($editMode): ?>
            <input type="hidden" wire:model="address_id" class="form-control">
        <?php endif; ?>

        <div class="row">
            <div class="col-lg-8 form-group">
                <label class="text-small text-uppercase" for="address_title"><?php echo e(__('Address title')); ?></label>
                <input class="form-control" wire:model="address_title" type="text" placeholder="<?php echo e(__('Enter your address title')); ?>">
                <?php $__errorArgs = ['address_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-4 form-group">
                <label class="text-small text-uppercase">&nbsp;</label>
                <div class="form-check">
                    <input class="form-check-input" id="default_address" wire:model="default_address" type="checkbox">
                    <label class="form-check-label" for="default_address"><?php echo e(__('Default address?')); ?></label>
                </div>
            </div>
            <div class="col-lg-6 form-group">
                <label class="text-small text-uppercase" for="first_name"><?php echo e(__('First name')); ?></label>
                <input class="form-control form-control-lg" wire:model="first_name" type="text" placeholder="<?php echo e(__('Enter your first name')); ?>">
                <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-6 form-group">
                <label class="text-small text-uppercase" for="last_name"><?php echo e(__('Last name')); ?></label>
                <input class="form-control form-control-lg" wire:model="last_name" type="text" placeholder="<?php echo e(__('Enter your last name')); ?>">
                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-6 form-group">
                <label class="text-small text-uppercase" for="email"><?php echo e(__('Email address')); ?></label>
                <input class="form-control form-control-lg" wire:model="email" type="email" placeholder="e.g. Jason@example.com">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-6 form-group">
                <label class="text-small text-uppercase" for="mobile"><?php echo e(__('Mobile number')); ?></label>
                <input class="form-control form-control-lg" wire:model="mobile" type="tel" placeholder="e.g. 966512345678">
                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-lg-6 form-group">
                <label class="text-small text-uppercase" for="address"><?php echo e(__('address')); ?></label>
                <input class="form-control form-control-lg" wire:model="address" type="text" placeholder="Enter your first address">
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-6 form-group">
                <label class="text-small text-uppercase" for="address2"><?php echo e(__('address2')); ?></label>
                <input class="form-control form-control-lg" wire:model="address2" type="text" placeholder="Enter your scand address">
                <?php $__errorArgs = ['address2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-4 form-group">
                <label class="text-small text-uppercase" for="country_id"><?php echo e(__('Country')); ?></label>
                <select class="form-control form-control-lg" wire:model="country_id">
                    <option value=""><?php echo e(__('Select Country')); ?></option>
                    <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </select>
                <?php $__errorArgs = ['country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-4 form-group">
                <label class="text-small text-uppercase" for="state_id"><?php echo e(__('State')); ?></label>
                <select class="form-control form-control-lg" wire:model="state_id">
                    <option value=""><?php echo e(__('Select State')); ?></option>
                    <?php $__empty_1 = true; $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </select>
                <?php $__errorArgs = ['state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-4 form-group">
                <label class="text-small text-uppercase" for="city_id"><?php echo e(__('City')); ?></label>
                <select class="form-control form-control-lg" wire:model="city_id">
                    <option value="" disabled><?php echo e(__('Select City')); ?></option>
                    <?php $__empty_1 = true; $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </select>
                <?php $__errorArgs = ['city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-lg-6 form-group">
                <label class="text-small text-uppercase" for="zip_code"><?php echo e(__('ZIP Code')); ?></label>
                <input class="form-control form-control-lg" wire:model="zip_code" type="text" placeholder="<?php echo e(__('Enter your ZIP Code')); ?>">
                <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-6 form-group">
                <label class="text-small text-uppercase" for="po_box"><?php echo e(__('P.O.Box')); ?></label>
                <input class="form-control form-control-lg" wire:model="po_box" type="text" placeholder="Enter your P.O.Box">
                <?php $__errorArgs = ['po_box'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-12 form-group">
                <button class="btn btn-dark" type="submit">
                    <?php echo e($editMode ? __('Update address') : __('Add address')); ?>

                </button>
            </div>
        </div>
    </form>

    <div class="my-4">
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th><?php echo e(__('Address title')); ?></th>
                    <th><?php echo e(__('Default')); ?></th>
                    <th class="col-2"><?php echo e(__('Action')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($address->address_title); ?></td>
                    <td><?php echo e($address->defaultAddress()); ?></td>
                    <td class="text-right">
                        <div class="btn-group btn-group-sm">
                            <button type="button" wire:click.prevent="edit_address('<?php echo e($address->id); ?>')" class="btn btn-success">
                                <i class="fa fa-edit"></i>
                            </button>
                            <button type="button" wire:click.prevent="delete_address('<?php echo e($address->id); ?>')" class="btn btn-danger">
                                <i class="fa fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3"><?php echo e(__('No addresses found')); ?></td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\store\resources\views/livewire/frontend/customer/addresses-component.blade.php ENDPATH**/ ?>