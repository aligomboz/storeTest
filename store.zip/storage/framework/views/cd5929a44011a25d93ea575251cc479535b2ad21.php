<?php $__env->startSection('content'); ?>
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row px-4 px-lg-5 py-lg-4 align-items-center">
                <div class="col-lg-6">
                    <h1 class="h2 text-uppercase mb-0"><?php echo e(__('Checkout')); ?></h1>
                </div>
                <div class="col-lg-6 text-lg-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-lg-end mb-0 px-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.index')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.cart')); ?>"><?php echo e(__('Cart')); ?></a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Checkout')); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section>

    <section class="py-5">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.checkout-component', [])->html();
} elseif ($_instance->childHasBeenRendered('SzCIySP')) {
    $componentId = $_instance->getRenderedChildComponentId('SzCIySP');
    $componentTag = $_instance->getRenderedChildComponentTagName('SzCIySP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('SzCIySP');
} else {
    $response = \Livewire\Livewire::mount('frontend.checkout-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('SzCIySP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/frontend/checkout.blade.php ENDPATH**/ ?>