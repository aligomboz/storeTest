<div class="col-lg-4">
    <div class="card border-0 rounded-0 p-lg-4 bg-light">
        <div class="card-body">
            <h5 class="text-uppercase mb-4"><?php echo e(__('Cart total')); ?></h5>
            <ul class="list-unstyled mb-0">
            <?php if($cart_total != 0): ?>
                <li class="d-flex align-items-center justify-content-between">
                    <strong class="text-uppercase small font-weight-bold"><?php echo e(__('Subtotal')); ?></strong>
                    <span class="text-muted small">$<?php echo e($cart_subtotal); ?></span>
                </li>
                <?php if(session()->has('coupon')): ?>
                    <li class="border-bottom my-2"></li>
                    <li class="d-flex align-items-center justify-content-between">
                        <strong class="small font-weight-bold"><?php echo e(__('Discount')); ?> <small>(<?php echo e(getNumbers()->get('discount_code')); ?>)</small></strong>
                        <span class="text-muted small">- $<?php echo e($cart_discount); ?></span>
                    </li>
                <?php endif; ?>
                <?php if(session()->has('shipping')): ?>
                    <li class="border-bottom my-2"></li>
                    <li class="d-flex align-items-center justify-content-between">
                        <strong class="small font-weight-bold"><?php echo e(__('Shipping')); ?> <small>(<?php echo e(getNumbers()->get('shipping_code')); ?>)</small></strong>
                        <span class="text-muted small">$<?php echo e($cart_shipping); ?></span>
                    </li>
                <?php endif; ?>

                <li class="border-bottom my-2"></li>
                <li class="d-flex align-items-center justify-content-between mb-4">
                    <strong class="text-uppercase small font-weight-bold"><?php echo e(__('Tax')); ?></strong>
                    <span>$<?php echo e($cart_tax); ?></span>
                </li>
                <li class="border-bottom my-2"></li>
                <li class="d-flex align-items-center justify-content-between mb-4">
                    <strong class="text-uppercase small font-weight-bold"><?php echo e(__('Total')); ?></strong>
                    <span>$<?php echo e($cart_total); ?></span>
                </li>
                <?php else: ?>
                    <li class="align-items-center justify-content-center mb-4">
                        <span><?php echo e(__('Your cart is empty!')); ?></span>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\store\resources\views/livewire/frontend/cart-total-component.blade.php ENDPATH**/ ?>