<footer class="bg-dark text-white">
    <div class="container py-4">
        
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\store\resources\views/partial/frontend/footer.blade.php ENDPATH**/ ?>