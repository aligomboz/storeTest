<?php $__env->startSection('content'); ?>
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row px-4 px-lg-5 py-lg-4 align-items-center">
                <div class="col-lg-6">
                    <h1 class="h2 text-uppercase mb-0"><?php echo e(__('Cart')); ?></h1>
                </div>
                <div class="col-lg-6 text-lg-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-lg-end mb-0 px-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.index')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Cart')); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section>
    <section class="py-5">
    <h2 class="h5 text-uppercase mb-4"><?php echo e(__('Shopping cart')); ?></h2>
    <div class="row">
        <div class="col-lg-8 mb-4 mb-lg-0">
            <!-- CART TABLE-->
            <div class="table-responsive mb-4">
                <table class="table">
                    <thead class="bg-light">
                    <tr>
                        <th class="border-0" scope="col"><strong class="text-small text-uppercase"><?php echo e(__('Product')); ?></strong></th>
                        <th class="border-0" scope="col"><strong class="text-small text-uppercase"><?php echo e(__('Price')); ?></strong></th>
                        <th class="border-0" scope="col"><strong class="text-small text-uppercase"><?php echo e(__('Quantity')); ?></strong></th>
                        <th class="border-0" scope="col"><strong class="text-small text-uppercase"><?php echo e(__('Total')); ?></strong></th>
                        <th class="border-0" scope="col"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.cart-item-component', ['item' => $item->rowId])->html();
} elseif ($_instance->childHasBeenRendered($item->rowId)) {
    $componentId = $_instance->getRenderedChildComponentId($item->rowId);
    $componentTag = $_instance->getRenderedChildComponentTagName($item->rowId);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($item->rowId);
} else {
    $response = \Livewire\Livewire::mount('frontend.cart-item-component', ['item' => $item->rowId]);
    $html = $response->html();
    $_instance->logRenderedChild($item->rowId, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="pl-0 border-light" colspan="5">
                                <p class="text-center">
                                    <?php echo e(__('No Items found in your cart!')); ?>

                                </p>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <!-- CART NAV-->
            <div class="bg-light px-4 py-3">
                <div class="row align-items-center text-center">
                    <div class="col-md-6 mb-3 mb-md-0 text-md-left">
                        <a class="btn btn-link p-0 text-dark btn-sm" href="<?php echo e(route('frontend.index')); ?>">
                            <i class="fas fa-long-arrow-alt-left mr-2"> </i><?php echo e(__('Continue shopping')); ?>

                        </a>
                    </div>
                    <div class="col-md-6 text-md-right">
                        <?php if(Cart::instance('default')->count() > 0): ?>
                            <a class="btn btn-outline-dark btn-sm" href="<?php echo e(route('frontend.checkout')); ?>">
                                <?php echo e(__('Proceed to checkout')); ?> <i class="fas fa-long-arrow-alt-right ml-2"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- ORDER TOTAL-->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.cart-total-component', [])->html();
} elseif ($_instance->childHasBeenRendered('lrCPdu6')) {
    $componentId = $_instance->getRenderedChildComponentId('lrCPdu6');
    $componentTag = $_instance->getRenderedChildComponentTagName('lrCPdu6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lrCPdu6');
} else {
    $response = \Livewire\Livewire::mount('frontend.cart-total-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('lrCPdu6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/frontend/cart.blade.php ENDPATH**/ ?>