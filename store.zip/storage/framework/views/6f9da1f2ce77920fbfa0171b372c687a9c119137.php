<?php $__env->startSection('content'); ?>

    <!-- HERO SECTION-->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row px-4 px-lg-5 py-lg-4 align-items-center">
                <div class="col-lg-6">
                    <h1 class="h2 text-uppercase mb-0"><?php echo e(__('Profile')); ?></h1>
                </div>
                <div class="col-lg-6 text-lg-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-lg-end mb-0 px-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.index')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('customer.profile')); ?>"><?php echo e(__('Profile')); ?></a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section>
    <section class="py-5">

        <div class="row ">
            <div class="col-lg-8 pt-2">
                <form action="<?php echo e(route('customer.update_profile')); ?>" method="post" enctype="multipart/form-data" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('patch'); ?>
                    <div class="row">
                        <div class="col-lg-12 text-center mb-4">
                            <?php if(auth()->user()->user_image != ''): ?>
                                <img src="<?php echo e(asset('assets/users/' . auth()->user()->user_image)); ?>" alt="<?php echo e(auth()->user()->full_name); ?>" class="img-thumbnail" width="120">
                                <div class="mt-2">
                                    <a href="<?php echo e(route('customer.remove_profile_image')); ?>" class="btn btn-sm btn-outline-danger"><?php echo e(__('Remove image')); ?></a>
                                </div>
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/users/avatar.svg')); ?>" alt="<?php echo e(auth()->user()->full_name); ?>" class="img-thumbnail" width="120">
                            <?php endif; ?>
                        </div>

                        <div class="col-lg-6 form-group">
                            <label class="text-small text-uppercase" for="first_name"><?php echo e(__('First name')); ?></label>
                            <input class="form-control form-control-lg" name="first_name" type="text" value="<?php echo e(old('first_name', auth()->user()->first_name)); ?>" placeholder="Enter your first name">
                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-lg-6 form-group">
                            <label class="text-small text-uppercase" for="last_name"><?php echo e(__('Last name')); ?></label>
                            <input class="form-control form-control-lg" name="last_name" type="text" value="<?php echo e(old('last_name', auth()->user()->last_name)); ?>" placeholder="Enter your last name">
                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-lg-6 form-group">
                            <label class="text-small text-uppercase" for="email"><?php echo e(__('Email address')); ?></label>
                            <input class="form-control form-control-lg" name="email" type="email" value="<?php echo e(old('email', auth()->user()->email)); ?>" placeholder="e.g. Jason@example.com">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-lg-6 form-group">
                            <label class="text-small text-uppercase" for="mobile"><?php echo e(__('Mobile number')); ?></label>
                            <input class="form-control form-control-lg" name="mobile" type="tel"  value="<?php echo e(old('mobile', auth()->user()->mobile)); ?>" placeholder="e.g. 966512345678">
                            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-lg-6 form-group">
                            <label class="text-small text-uppercase d-flex" for="password"><?php echo e(__('Password')); ?> <small class="ml-auto text-danger">(Optional)</small></label>
                            <input class="form-control form-control-lg" name="password" type="password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-lg-6 form-group">
                            <label class="text-small text-uppercase d-flex" for="password_confirmation"><?php echo e(__('Re-Password')); ?> <small class="ml-auto text-danger">(Optional)</small></label>
                            <input class="form-control form-control-lg" name="password_confirmation" type="password">
                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-lg-12 form-group">
                            <label class="text-small text-uppercase" for="user_image"><?php echo e(__('Image')); ?></label>
                            <input class="form-control form-control-lg" name="user_image" type="file">
                            <?php $__errorArgs = ['user_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-lg-12 form-group">
                            <button class="btn btn-dark" type="submit"><?php echo e(__('Update profile')); ?></button>
                        </div>
                    </div>

                </form>
            </div>

            <!-- ORDER SUMMARY-->
            <div class="col-lg-4">
                <?php echo $__env->make('partial.frontend.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/frontend/customer/profile.blade.php ENDPATH**/ ?>