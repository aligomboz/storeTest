<div x-data="{ showOrder: <?php if ((object) ('showOrder') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('showOrder'->value()); ?>')<?php echo e('showOrder'->hasModifier('defer') ? '.defer' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('showOrder'); ?>')<?php endif; ?> }">
    <div class="d-flex">
        <h2 class="h5 text-uppercase mb-4"><?php echo e(__('Orders')); ?></h2>
    </div>

    <?php if($orders): ?>
        <div class="my-4">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th><?php echo e(__('Order Ref')); ?>.</th>
                            <th><?php echo e(__('Total')); ?></th>
                            <th><?php echo e(__('Status')); ?></th>
                            <th><?php echo e(__('Date')); ?></th>
                            <th class="col-2"><?php echo e(__('Action')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        
                        
                        
                    
                       <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr wire:key="<?php echo e($order->id); ?>">
                            <td><?php echo e($order->ref_id); ?></td>
                            <td><?php echo e($order->currency() . ' ' . $order->total); ?></td>
                            <td><?php echo $order->statusWithLabel(); ?></td>
                            <td><?php echo e($order->created_at->format('d-m-Y')); ?></td>
                            <td class="text-right">
                                <button type="button" wire:click="displayOrder('<?php echo e($order->id); ?>')"
                                    x-on:click="showOrder = true" class="btn btn-success btn-sm">
                                    <i class="fa fa-eye"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5">
                                <p class="text-center"><?php echo e(__('No orders found.')); ?></p>
                            </td>
                        </tr>
                    <?php endif; ?> 

                        
                    </tbody>
                </table>
            </div>

            <div x-show="showOrder" x-on:click.away="showOrder = false" class="border rounded shadow p-4">
                <div class="table-responsive mb-4">
                    <table class="table">
                        <thead class="bg-light">
                            <tr>
                                <th class="border-0" scope="col"><strong
                                        class="text-small text-uppercase"><?php echo e(__('Product')); ?></strong></th>
                                <th class="border-0" scope="col"><strong
                                        class="text-small text-uppercase"><?php echo e(__('Price')); ?></strong></th>
                                <th class="border-0" scope="col"><strong
                                        class="text-small text-uppercase"><?php echo e(__('Quantity')); ?></strong></th>
                                <th class="border-0" scope="col"><strong
                                        class="text-small text-uppercase"><?php echo e(__('Total')); ?></strong></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($product->name); ?></td>
                                    <td><?php echo e($order->currency() . ' ' . number_format($product->price, 2)); ?></td>
                                    <td><?php echo e($product->pivot->quantity); ?></td>
                                    <td><?php echo e($order->currency() . ' ' . number_format($product->price * $product->pivot->quantity, 2)); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td colspan="3" class="text-right"><strong><?php echo e(__('Subtotal')); ?></strong></td>
                                <td><?php echo e($order->currency() . ' ' . number_format($order->subtotal, 2)); ?></td>
                            </tr>
                            <?php if(!is_null($order->discount_code)): ?>
                                <tr>
                                    <td colspan="3" class="text-right"><strong><?php echo e(__('Discount')); ?>

                                            (<small><?php echo e($order->discount_code); ?></small>)</strong></td>
                                    <td><?php echo e($order->currency() . ' ' . number_format($order->discount, 2)); ?></td>
                                </tr>
                            <?php endif; ?>
                            <tr>
                                <td colspan="3" class="text-right"><strong><?php echo e(__('Tax')); ?></strong></td>
                                <td><?php echo e($order->currency() . ' ' . number_format($order->tax, 2)); ?></td>
                            </tr>
                            <tr>
                                <td colspan="3" class="text-right"><strong><?php echo e(__('Shipping')); ?></strong></td>
                                <td><?php echo e($order->currency() . ' ' . number_format($order->shipping, 2)); ?></td>
                            </tr>
                            <tr>
                                <td colspan="3" class="text-right"><strong><?php echo e(__('Amount')); ?></strong></td>
                                <td><?php echo e($order->currency() . ' ' . number_format($order->total, 2)); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <h2 class="h5 text-uppercase"><?php echo e(__('Transactions')); ?></h2>
                <div class="table-responsive mb-4">
                    <table class="table">
                        <thead class="bg-light">
                            <tr>
                                <th class="border-0" scope="col"><strong
                                        class="text-small text-uppercase"><?php echo e(__('Transaction')); ?></strong></th>
                                <th class="border-0" scope="col"><strong
                                        class="text-small text-uppercase"><?php echo e(__('Date')); ?></strong></th>
                                
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $order->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($transaction->status($transaction->transaction)); ?></td>
                                    <td><?php echo e($transaction->created_at->format('Y-m-d')); ?></td>
                                    
                                    <td>
                                        <?php if($loop->last &&
                                            $transaction->transaction == \App\Models\OrderTransaction::FINISHED &&
                                            \Carbon\Carbon::now()->addDays(5)->diffInDays($transaction->created_at->format('Y-m-d')) != 0): ?>
                                            <button type="button"
                                                wire:click="requestReturnOrder('<?php echo e($order->id); ?>')"
                                                class="btn btn-link text-right"> <?php echo e(__('you can return order in')); ?>

                                                <?php echo e(5 - $transaction->created_at->diffInDays()); ?> <?php echo e(__('days')); ?>

                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\store\resources\views/livewire/frontend/customer/orders-component.blade.php ENDPATH**/ ?>