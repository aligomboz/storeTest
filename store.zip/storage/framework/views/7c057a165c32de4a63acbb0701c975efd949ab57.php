<div class="card-body">
    <form action="<?php echo e(route('admin.orders.index')); ?>" method="get">
        <div class="row">
            <div class="col-2">
                <div class="form-group">
                    <input type="text" name="keyword" value="<?php echo e(old('keyword', request()->input('keyword'))); ?>" class="form-control" placeholder="Search here">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <select name="status" class="form-control">
                        <option value="">---</option>
                        <option value="0" <?php echo e(old('status', request()->input('status')) == '0' ? 'selected' : ''); ?>>New order</option>
                        <option value="1" <?php echo e(old('status', request()->input('status')) == '1' ? 'selected' : ''); ?>>Paid</option>
                        <option value="2" <?php echo e(old('status', request()->input('status')) == '2' ? 'selected' : ''); ?>>Under process</option>
                        <option value="3" <?php echo e(old('status', request()->input('status')) == '3' ? 'selected' : ''); ?>>Finished</option>
                        <option value="4" <?php echo e(old('status', request()->input('status')) == '4' ? 'selected' : ''); ?>>Rejected</option>
                        <option value="5" <?php echo e(old('status', request()->input('status')) == '5' ? 'selected' : ''); ?>>Canceled</option>
                        <option value="6" <?php echo e(old('status', request()->input('status')) == '6' ? 'selected' : ''); ?>>Refund requested</option>
                        <option value="7" <?php echo e(old('status', request()->input('status')) == '7' ? 'selected' : ''); ?>>Refunded</option>
                        <option value="8" <?php echo e(old('status', request()->input('status')) == '8' ? 'selected' : ''); ?>>Returned order</option>
                    </select>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <select name="sort_by" class="form-control">
                        <option value="">---</option>
                        <option value="id" <?php echo e(old('sort_by', request()->input('sort_by')) == 'id' ? 'selected' : ''); ?>>ID</option>
                        <option value="name" <?php echo e(old('sort_by', request()->input('sort_by')) == 'name' ? 'selected' : ''); ?>>Name</option>
                        <option value="created_at" <?php echo e(old('sort_by', request()->input('sort_by')) == 'created_at' ? 'selected' : ''); ?>>Created at</option>
                    </select>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <select name="order_by" class="form-control">
                        <option value="">---</option>
                        <option value="asc" <?php echo e(old('order_by', request()->input('order_by')) == 'asc' ? 'selected' : ''); ?>>Ascending</option>
                        <option value="desc" <?php echo e(old('order_by', request()->input('order_by')) == 'desc' ? 'selected' : ''); ?>>Descending</option>
                    </select>
                </div>
            </div>
            <div class="col-1">
                <div class="form-group">
                    <select name="limit_by" class="form-control">
                        <option value="">---</option>
                        <option value="10" <?php echo e(old('limit_by', request()->input('limit_by')) == '10' ? 'selected' : ''); ?>>10</option>
                        <option value="20" <?php echo e(old('limit_by', request()->input('limit_by')) == '20' ? 'selected' : ''); ?>>20</option>
                        <option value="50" <?php echo e(old('limit_by', request()->input('limit_by')) == '50' ? 'selected' : ''); ?>>50</option>
                        <option value="100" <?php echo e(old('limit_by', request()->input('limit_by')) == '100' ? 'selected' : ''); ?>>100</option>
                    </select>
                </div>
            </div>
            <div class="col-2"></div>
            <div class="col-1">
                <div class="form-group">
                    <button type="submit" class="btn btn-link">Search</button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\store\resources\views/backend/orders/filter/filter.blade.php ENDPATH**/ ?>