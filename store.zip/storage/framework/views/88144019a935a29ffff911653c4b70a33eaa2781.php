<?php $__env->startSection('content'); ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex">
            <h6 class="m-0 font-weight-bold text-primary">Supervisors</h6>
            <div class="ml-auto">
                <a href="<?php echo e(route('admin.supervisors.create')); ?>" class="btn btn-primary">
                    <span class="icon text-white-50">
                        <i class="fa fa-plus"></i>
                    </span>
                    <span class="text">Add new supervisor</span>
                </a>
            </div>
        </div>

        <?php echo $__env->make('backend.supervisors.filter.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Email & Mobile</th>
                    <th>Status</th>
                    <th>Created at</th>
                    <th class="text-center" style="width: 30px;">Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $supervisors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php if($supervisor->user_image != ''): ?>
                                <img src="<?php echo e(asset('assets/users/'. $supervisor->user_image)); ?>" width="60" height="60" alt="<?php echo e($supervisor->name); ?>">
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/users/avatar.svg')); ?>" width="60" height="60" alt="<?php echo e($supervisor->name); ?>">
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo e($supervisor->full_name); ?><br>
                            <strong><?php echo e($supervisor->username); ?></strong>
                        </td>
                        <td>
                            <?php echo e($supervisor->email); ?><br>
                            <?php echo e($supervisor->mobile); ?>

                        </td>
                        <td><?php echo e($supervisor->status()); ?></td>
                        <td><?php echo e($supervisor->created_at->format('Y-m-d')); ?></td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <a href="<?php echo e(route('admin.supervisors.edit', $supervisor->id)); ?>" class="btn btn-primary">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <a href="javascript:void(0);" onclick="if (confirm('Are you sure to delete this record?')) { document.getElementById('delete-supervisor-<?php echo e($supervisor->id); ?>').submit(); } else { return false; }" class="btn btn-danger">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </div>
                            <form action="<?php echo e(route('admin.supervisors.destroy', $supervisor->id)); ?>" method="post" id="delete-supervisor-<?php echo e($supervisor->id); ?>" class="d-none">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">No supervisors found</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="6">
                            <div class="float-right">
                                <?php echo $supervisors->appends(request()->all())->links(); ?>

                            </div>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/backend/supervisors/index.blade.php ENDPATH**/ ?>