<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    </div>

    <!-- Content Row -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.dashboard.statistics-component', [])->html();
} elseif ($_instance->childHasBeenRendered('J9xpw6x')) {
    $componentId = $_instance->getRenderedChildComponentId('J9xpw6x');
    $componentTag = $_instance->getRenderedChildComponentTagName('J9xpw6x');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('J9xpw6x');
} else {
    $response = \Livewire\Livewire::mount('backend.dashboard.statistics-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('J9xpw6x', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- Content Row -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.dashboard.chart-component', [])->html();
} elseif ($_instance->childHasBeenRendered('3tLeqSA')) {
    $componentId = $_instance->getRenderedChildComponentId('3tLeqSA');
    $componentTag = $_instance->getRenderedChildComponentTagName('3tLeqSA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3tLeqSA');
} else {
    $response = \Livewire\Livewire::mount('backend.dashboard.chart-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('3tLeqSA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/backend/index.blade.php ENDPATH**/ ?>