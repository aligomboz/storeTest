<header class="header bg-white">
    <div class="container px-0 px-lg-3">
        <nav class="navbar navbar-expand-lg navbar-light py-3 px-lg-0">
            <a class="navbar-brand" href="<?php echo e(route('frontend.index')); ?>">
                <span class="font-weight-bold text-uppercase text-dark"><?php echo e(__('beauty products store')); ?></span>
            </a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(route('frontend.index')); ?>"><?php echo e(__('Home')); ?></a>
                    </li>
                    <li class="nav-item">
                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p style="display: inline-block">
                                <?php if($localeCode != app()->getLocale()): ?>
                                    <a style="font-size: 17px" class="text-warning px-4" rel="alternate" hreflang="<?php echo e($localeCode); ?>"
                                        href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                        <?php echo e($properties['native']); ?>

                                    </a>
                                <?php endif; ?>

                            </p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.carts', [])->html();
} elseif ($_instance->childHasBeenRendered('uBNpZpT')) {
    $componentId = $_instance->getRenderedChildComponentId('uBNpZpT');
    $componentTag = $_instance->getRenderedChildComponentTagName('uBNpZpT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uBNpZpT');
} else {
    $response = \Livewire\Livewire::mount('frontend.carts', []);
    $html = $response->html();
    $_instance->logRenderedChild('uBNpZpT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">
                                <i class="fas fa-user-alt mr-1 text-gray"></i><?php echo e(__('Login')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>">
                                <i class="fas fa-user-alt mr-1 text-gray"></i><?php echo e(__('Register')); ?>

                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.header.notification-component', [])->html();
} elseif ($_instance->childHasBeenRendered('iIGw3hT')) {
    $componentId = $_instance->getRenderedChildComponentId('iIGw3hT');
    $componentTag = $_instance->getRenderedChildComponentTagName('iIGw3hT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('iIGw3hT');
} else {
    $response = \Livewire\Livewire::mount('frontend.header.notification-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('iIGw3hT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </li>

                        <li class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" id="authDropdown" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <?php echo e(auth()->user()->full_name); ?>

                            </a>
                            <div class="dropdown-menu mt-3" aria-labelledby="authDropdown">
                                <a href="<?php echo e(route('customer.profile')); ?>" class="dropdown-item border-0"><?php echo e(__('Dashboard')); ?></a>
                                <a href="javascript:void(0);" class="dropdown-item border-0"
                                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a>
                                <form action="<?php echo e(route('logout')); ?>" method="post" id="logout-form"
                                    class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\store\resources\views/partial/frontend/header.blade.php ENDPATH**/ ?>