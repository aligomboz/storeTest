<?php $__env->startSection('content'); ?>

    <!-- HERO SECTION-->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row px-4 px-lg-5 py-lg-4 align-items-center">
                <div class="col-lg-6">
                    <h1 class="h2 text-uppercase mb-0"><?php echo e(auth()->user()->full_name); ?> <?php echo e(__('Orders')); ?></h1>
                </div>
                <div class="col-lg-6 text-lg-right">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-lg-end mb-0 px-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.index')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('customer.orders')); ?>"><?php echo e(__('Orders')); ?></a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section>
    <section class="py-5">

        <div class="row">
            <div class="col-lg-8">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.customer.orders-component', [])->html();
} elseif ($_instance->childHasBeenRendered('9mIPWSQ')) {
    $componentId = $_instance->getRenderedChildComponentId('9mIPWSQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('9mIPWSQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9mIPWSQ');
} else {
    $response = \Livewire\Livewire::mount('frontend.customer.orders-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('9mIPWSQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>


            <!-- SIDEBAR -->
            <div class="col-lg-4">
                <?php echo $__env->make('partial.frontend.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>


    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/frontend/customer/orders.blade.php ENDPATH**/ ?>