<div class="card border-0 rounded-0 p-lg-4 bg-light">
    <div class="card-body">
        <h5 class="text-uppercase mb-4"><?php echo e(__('Navigation bar')); ?></h5>
        
        <div class="py-2 px-4 mb-3 <?php echo e(Route::currentRouteName() == 'customer.profile' ? 'bg-dark text-white' : 'bg-light'); ?>">
            <a href="<?php echo e(route('customer.profile')); ?>">
                <strong class="small text-uppercase font-weight-bold"><?php echo e(__('Profile')); ?></strong>
            </a>
        </div>
        <div class="py-2 px-4 mb-3 <?php echo e(Route::currentRouteName() == 'customer.addresses' ? 'bg-dark text-white' : 'bg-light'); ?>">
            <a href="<?php echo e(route('customer.addresses')); ?>">
                <strong class="small text-uppercase font-weight-bold"><?php echo e(__('Addresses')); ?></strong>
            </a>
        </div>
        <div class="py-2 px-4 mb-3 <?php echo e(Route::currentRouteName() == 'customer.orders' ? 'bg-dark text-white' : 'bg-light'); ?>">
            <a href="<?php echo e(route('customer.orders')); ?>">
                <strong class="small text-uppercase font-weight-bold"><?php echo e(__('Orders')); ?></strong>
            </a>
        </div>
        <div class="py-2 px-4 mb-3 bg-light">
            <a href="javascript:void(0);" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                <strong class="small text-uppercase font-weight-bold"><?php echo e(__('Logout')); ?></strong>
            </a>
            
        </div>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\store\resources\views/partial/frontend/customer/sidebar.blade.php ENDPATH**/ ?>