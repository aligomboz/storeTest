<?php $__env->startSection('content'); ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex">
            <h6 class="m-0 font-weight-bold text-primary">Order (<?php echo e($order->ref_id); ?>)</h6>
            <div class="ml-auto">
                <form action="<?php echo e(route('admin.orders.update', $order->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-row align-items-center">
                        <label class="sr-only" for="inlineFormInputGroupUsername">Order status</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <div class="input-group-text">Order status</div>
                            </div>
                            <select class="form-control" name="order_status" style="outline-style: none;" onchange="this.form.submit()">
                                <option value=""> Choose your action </option>
                                <?php $__currentLoopData = $order_status_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="d-flex">
            <div class="col-8">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <tbody>
                        <tr>
                            <th>Ref. Id</th>
                            <td><?php echo e($order->ref_id); ?></td>
                            <th>Customer</th>
                            <td><a href="<?php echo e(route('admin.customers.show', $order->user_id)); ?>"><?php echo e($order->user->full_name); ?></a></td>
                        </tr>
                        <tr>
                            <th>Address</th>
                            <td><a href="<?php echo e(route('admin.customer_addresses.show', $order->user_address_id)); ?>"><?php echo e($order->user_address->address_title); ?></a></td>
                            <th>Shipping Company</th>
                            <td><?php echo e($order->shipping_company->name . '('. $order->shipping_company->code .')'); ?></td>
                        </tr>
                        <tr>
                            <th>Created date</th>
                            <td><?php echo e($order->created_at->format('d-m-Y h:i a')); ?></td>
                            <th>Order status</th>
                            <td><?php echo $order->statusWithLabel(); ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-4">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <tbody>
                        <tr>
                            <th>Subtotal</th>
                            <td><?php echo e($order->currency() . $order->subtotal); ?></td>
                        </tr>
                        <tr>
                            <th>Discount code</th>
                            <td><?php echo e($order->discount_code); ?></td>
                        </tr>
                        <tr>
                            <th>Discount</th>
                            <td><?php echo e($order->currency() . $order->discount); ?></td>
                        </tr>
                        <tr>
                            <th>Shipping</th>
                            <td><?php echo e($order->currency() . $order->shipping); ?></td>
                        </tr>
                        <tr>
                            <th>tax</th>
                            <td><?php echo e($order->currency() . $order->tax); ?></td>
                        </tr>
                        <tr>
                            <th>Amount</th>
                            <td><?php echo e($order->currency() . $order->total); ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Transactions</h6>
        </div>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>Transaction</th>
                    <th>Transaction number</th>
                    <th>Payment result</th>
                    <th>Action date</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $order->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($transaction->status($transaction->transaction)); ?></td>
                        <td><?php echo e($transaction->transaction_number); ?></td>
                        <td><?php echo e($transaction->payment_result); ?></td>
                        <td><?php echo e($transaction->created_at->format('Y-m-d h:i a')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">No transactions found</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Details</h6>
        </div>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>Product</th>
                    <th>Quantity</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><a href="<?php echo e(route('admin.products.show', $product->id)); ?>"><?php echo e($product->name); ?></a></td>
                        <td><?php echo e($product->pivot->quantity); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="2">No products found</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/backend/orders/show.blade.php ENDPATH**/ ?>